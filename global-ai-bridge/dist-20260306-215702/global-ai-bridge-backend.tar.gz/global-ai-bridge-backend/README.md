# AI Bridge for WordPress

AI Bridge is a WordPress plugin that connects WordPress AI features to global AI models through your own proxy gateway.

It is designed for environments where direct access to AI APIs (OpenAI, Gemini, Claude, etc.) may be restricted or unstable, such as servers located in mainland China or Hong Kong.

AI Bridge allows WordPress to communicate with AI providers through a self-hosted proxy server running on a VPS.

## Documentation

- [Plugin Overview](./PLUGIN.md)
- [Usage Guide](./USAGE.md)
- [Changelog](./CHANGELOG.md)
- [Gateway Backend](./server/README.md)
- [Deployment Guide](./DEPLOY.md)
- [1Panel Deploy Guide](./1PANEL-DEPLOY.md)
- [Blog Draft: Custom Endpoint Security](./BLOG-CUSTOM-ENDPOINT.md)

## Features

- Connect WordPress to AI models through a proxy gateway
- Support OpenAI / Gemini / Claude / DeepSeek
- Works with WordPress AI integrations
- Secure API key management
- Custom proxy endpoint
- Compatible with China / Hong Kong servers
- Token usage logging
- Multi-model routing
- Optional caching

## Architecture

AI Bridge uses a simple relay architecture:

1. WordPress sends AI requests through the AI Bridge plugin.
2. The plugin forwards requests to your private proxy gateway.
3. The proxy gateway authenticates the request, selects the target provider, and relays it to the upstream AI API.
4. The upstream provider returns the response to the proxy.
5. The proxy sends the normalized result back to WordPress.

This design keeps provider credentials and routing logic outside the WordPress server while allowing WordPress plugins or custom features to use AI capabilities through one stable endpoint.

### High-Level Flow

```text
+-------------------+       +---------------------+       +----------------------+
| WordPress Site    | ----> | AI Bridge Plugin    | ----> | Private Proxy Gateway|
| (admin/frontend)  |       | (WP integration)    |       | (routing/auth/cache) |
+-------------------+       +---------------------+       +----------------------+
                                                                    |
                                                                    v
                                                        +--------------------------+
                                                        | AI Providers             |
                                                        | OpenAI / Gemini / Claude |
                                                        | DeepSeek / Others        |
                                                        +--------------------------+
```

### Core Components

#### 1. WordPress Plugin Layer

The plugin is responsible for:

- exposing plugin settings in WordPress admin
- storing proxy configuration securely
- registering model/provider options
- sending requests from WordPress AI features to the proxy
- handling responses, errors, and usage metadata

#### 2. Proxy Gateway Layer

The proxy gateway is responsible for:

- receiving requests from trusted WordPress sites
- validating authentication tokens or signed requests
- routing each request to the correct AI provider
- normalizing provider-specific request and response formats
- applying retry, timeout, logging, and optional caching policies

#### 3. AI Provider Layer

The upstream provider layer may include:

- OpenAI
- Google Gemini
- Anthropic Claude
- DeepSeek
- other compatible LLM providers

Each provider may use different API formats, authentication schemes, and model naming. The proxy gateway abstracts these differences so WordPress only needs to talk to one endpoint.

## Request Lifecycle

1. A WordPress feature triggers an AI request.
2. AI Bridge prepares a payload containing prompt, model, and request options.
3. The payload is sent to the configured proxy endpoint.
4. The proxy applies routing rules and forwards the request upstream.
5. The provider response is normalized and returned to WordPress.
6. AI Bridge logs usage data such as provider, model, token count, latency, and error status if enabled.

## Security Model

AI Bridge is designed to reduce direct exposure of provider credentials on the WordPress server.

- WordPress stores only the proxy endpoint and site-level authentication data
- provider API keys remain on the proxy gateway
- access control can be enforced centrally on the proxy
- traffic policy, rate limits, and logs can be managed outside WordPress

## Use Cases

- WordPress sites hosted in regions with unstable access to global AI APIs
- teams that want to centralize AI provider management across multiple WordPress sites
- deployments that require provider failover or model routing
- environments that want logging, caching, or auditing at the gateway layer

## Future Expansion

Potential future capabilities include:

- provider failover when one upstream service is unavailable
- per-site quotas and billing controls
- streaming response support
- prompt templating
- analytics dashboards
- role-based access control for model usage

## Summary

AI Bridge gives WordPress a stable and controllable path to modern AI models by placing a private proxy gateway between WordPress and upstream AI providers. This makes the system more portable, more resilient in restricted network environments, and easier to manage across multiple providers.
