# Server Sizing Guide

## Recommended starting point

For the AI Bridge Go backend, the first production node should usually start at:

- `2 vCPU`
- `4 GB RAM`
- `40 GB SSD`

This is enough for:

- Go gateway
- Nginx or Caddy
- Docker
- basic logs
- moderate request concurrency

## Why the gateway is not compute-heavy

AI Bridge does not run the model locally. The gateway mainly does:

- token validation
- request parsing
- upstream forwarding
- response normalization
- logging

The main operational pressure is not CPU-intensive inference. It is usually:

- connection concurrency
- slow upstream responses
- request timeouts
- bandwidth
- logs and monitoring

## Suggested server tiers

### Small traffic

- `1 vCPU / 2 GB RAM`
- suitable for development, internal testing, or very low customer traffic

### Recommended launch tier

- `2 vCPU / 4 GB RAM`
- suitable for first public customers

### Medium traffic

- `4 vCPU / 8 GB RAM`
- suitable for more concurrent customers or multiple WordPress sites

### Multi-region deployment

For `US`, `SG`, and `JP` nodes:

- start each node at `2 vCPU / 4 GB RAM`
- increase only when one region shows sustained latency or queueing pressure

## Production checklist

- put Nginx or Caddy in front of the Go service
- enable HTTPS
- enable firewall rules
- use Docker restart policies
- keep provider API keys in environment variables
- enable rate limiting
- monitor `healthz` and `metrics`

## When to scale

Scale up or split nodes when you see:

- rising `429` rate-limit responses
- many concurrent slow upstream calls
- frequent upstream timeouts
- memory pressure from too many open requests
- customers in multiple distant regions
